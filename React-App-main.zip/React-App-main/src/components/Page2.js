import React from 'react';
import './Page2.css';

function Page2() {
  return (
    <div className="page2">
      <h2>About Neuro Styles</h2>
      <p>This is the second page of our application.</p>
      <p>Here you can find more information about our company and mission.</p>
    </div>
  );
}

export default Page2;
