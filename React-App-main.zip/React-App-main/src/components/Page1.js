import React from 'react';
import './Page1.css';

function Page1() {
  return (
    <div className="page1">
      <h2>Welcome to Neuro Styles</h2>
      <p>This is the first page of our application.</p>
      <p>Here you can find information about our products and services.</p>
    </div>
  );
}

export default Page1;
