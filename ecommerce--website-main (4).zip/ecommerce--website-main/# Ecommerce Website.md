# Ecommerce Website

## Running the Project

1. Navigate to your Django project folder:
    ```bash
    cd mysite
    ```

2. Start the server:
    ```bash
    python manage.py runserver
    ```

3. Open your web browser and go to `http://127.0.0.1:8000/` to see the website.